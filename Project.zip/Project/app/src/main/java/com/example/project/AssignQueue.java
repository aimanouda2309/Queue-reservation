package com.example.project;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Calendar;

public class AssignQueue extends AppCompatActivity {
    static ArrayList<String> TodayEmptyHours;
    private int index=0;
    private Button previous,next;
    private TextView textView;
    private int currentyear,currentmonth,currentday;
    private EditText comment;
    //Here on create we set all of our parameters and we load the queue
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emptyqueue);
        getSupportActionBar().setTitle("Empty Queues");
        CalendarView calendarView = (CalendarView) findViewById(R.id.calendarView2);
        comment = (EditText) findViewById(R.id.descreption);
        long date = calendarView.getDate();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date);
        currentyear = calendar.get(Calendar.YEAR);
        currentmonth = calendar.get(Calendar.MONTH)+1;
        currentday = calendar.get(Calendar.DAY_OF_MONTH);
        textView = (TextView) findViewById(R.id.textView2);
        previous = (Button) findViewById(R.id.prev2);
        next = (Button) findViewById(R.id.next2);
        previous.setEnabled(false);
        next.setEnabled(false);
        LoadQueue load = new LoadQueue(currentyear, currentmonth, currentday);
        load.execute("");
        TodayEmptyHours=new ArrayList<>();
        index=0;
        //here we load all of the empty queue of this specific date that has been clicked
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                currentyear=year;
                currentday=dayOfMonth;
                currentmonth=month+1;
                LoadQueue load = new LoadQueue(currentyear, currentmonth, currentday);
                load.execute("");
                TodayEmptyHours=new ArrayList<>();
                index=0;
                previous.setEnabled(false);
                next.setEnabled(false);

            }
        });
    }
    //here we fill the empty queue on the arraylist and we display them with appropriately to the client
    public void FillEmptyQueue(ArrayList<Queue> TodayBusyQueue){
        int hour=8,minute=0;
        int flag=0;
        int endhour,endminute;
        TodayEmptyHours=new ArrayList<>();
        comment.getText().clear();
        if(TodayBusyQueue!=null) {
            Log.i("s", "vv" + Integer.parseInt(TodayBusyQueue.get(0).getHour())+Integer.parseInt(TodayBusyQueue.get(0).getMin()));
        }
        while(hour<18){
            if(TodayBusyQueue!=null) {
                for (int i = 0; i < TodayBusyQueue.size(); i++) {
                    if (Integer.parseInt(TodayBusyQueue.get(i).getHour()) == hour && Integer.parseInt(TodayBusyQueue.get(i).getMin()) == minute) {
                        flag = 1;
                        break;
                    }
                }
            }
            if(flag==0){
                if(minute==30)
                {
                    endhour=hour+1;
                    endminute=0;
                    TodayEmptyHours.add(hour+":"+minute+"-"+endhour+":"+endminute+'0');
                    minute=endminute;
                    hour=endhour;
                }
                else {
                    endhour = hour;
                    endminute = 30;
                    TodayEmptyHours.add(hour + ":" + minute +'0'+ "-" + endhour + ":" + endminute);
                    minute = endminute;
                    hour = endhour;
                }
            }
            else{
                if(minute==30)
                {
                    minute=0;
                    hour++;
                }
                else {
                    minute = 30;
                }
                flag=0;
            }
        }
        setTextView();
    }
    //Here we set the textview where the client can see the empty queues that available
    public void setTextView(){
        if(TodayEmptyHours.size()>0) {
            next.setEnabled(true);
            textView.setText(currentyear+"-"+currentmonth+"-"+currentday+"\n"+TodayEmptyHours.get(index));
        }
        else
            textView.setText(currentyear+"-"+currentmonth+"-"+currentday+"\nNo Empty Hours for today");
    }

    //when the customer click on next button we set the text view to the next queue of the current date
    public void Next(View view) {
        index++;
        previous.setEnabled(true);
        textView.setText(currentyear+"-"+currentmonth+"-"+currentday+"\n"+TodayEmptyHours.get(index));
        if(TodayEmptyHours.size()==index+1)
            next.setEnabled(false);
    }

    //when the customer click on previous button we set the text view to the previous queue of the current date
    public void Previous(View view) {
        index--;
        next.setEnabled(true);
        textView.setText(currentyear+"-"+currentmonth+"-"+currentday+"\n"+TodayEmptyHours.get(index));
        if(index==0)
            previous.setEnabled(false);
    }
    //when the client click on assign button this function call the
    public void Assign(View view) {
        String Starthour=((TodayEmptyHours.get(index).split("-"))[0].split(":"))[0];
        String Startminute=((TodayEmptyHours.get(index).split("-"))[0].split(":"))[1];
        String Endhour=((TodayEmptyHours.get(index).split("-"))[1].split(":"))[0];
        String Endminute=((TodayEmptyHours.get(index).split("-"))[1].split(":"))[1];
        AssignQueueDB load = new AssignQueueDB(currentyear, currentmonth, currentday,Starthour,Startminute,Endhour,Endminute,comment.getText().toString());
        load.execute("");
    }
    //Thread to load the empty queue at specific date from DB
    private class LoadQueue extends AsyncTask<String, Void, ArrayList<Queue>> {
        int year;
        int month;
        int dayOfMonth;

        public LoadQueue(int year, int month, int dayOfMonth) {
            this.year = year;
            this.month = month;
            this.dayOfMonth = dayOfMonth;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadqueueat(year, month, dayOfMonth);
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
            if (result != null) {
                FillEmptyQueue(result);
            } else {
                textView.setText(currentyear+"-"+currentmonth+"-"+currentday+"\nNo Empty Hours for today");
                FillEmptyQueue(result);
                Log.i("ss", "cv");
            }
            //dialog3.dismiss();
        }
    }
    //Thread to save this queue for this customer on the DB
    private class AssignQueueDB extends AsyncTask<String, Void, Boolean> {
        int year;
        int month;
        int dayOfMonth;
        String Starthour;
        String Startminute;
        String Endhour;
        String Endminute;
        String comment;

        public AssignQueueDB(int year, int month, int dayOfMonth,String Starthour,String Startminute,String Endhour,String Endminute,String comment) {
            this.year = year;
            this.month = month;
            this.dayOfMonth = dayOfMonth;
            this.Starthour=Starthour;
            this.Startminute=Startminute;
            this.Endhour=Endhour;
            this.Endminute=Endminute;
            this.comment=comment;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Boolean doInBackground(String... params) {
            return dbConnection.assignqueue(year, month, dayOfMonth,Starthour,Startminute,Endhour,Endminute,comment);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(MainActivity.context, "Meeting has been assigned", Toast.LENGTH_SHORT)
                        .show();
                LoadQueue load = new LoadQueue(currentyear, currentmonth, currentday);
                load.execute("");
            } else {
                Toast.makeText(MainActivity.context, "Meeting didn't assigned", Toast.LENGTH_SHORT)
                        .show();
            }
            //dialog3.dismiss();
        }
    }
}
