package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;



import java.util.ArrayList;

//Main activity (this is the first activity that start)
public class MainActivity extends AppCompatActivity {
    static ArrayList<Queue> queues=new ArrayList<>();
    static Context context;
    static Dialog dialog3=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        context=MainActivity.this;
    }

    //User Login action
    public void login(View view) {
        String Username = ((EditText) findViewById(R.id.editTextUsername1)).getText().toString();
        String Password = ((EditText) findViewById(R.id.editTextPassword1)).getText().toString();
        LoadingShow();
        CheckUsernamePassword check = new CheckUsernamePassword(Username, Password);
        check.execute("");

    }
    //User Signup action
    public void SignUp(View view) {
        Intent myIntent = new Intent(MainActivity.this, RegistrationActivity.class);
        MainActivity.this.startActivity(myIntent);
        this.finish();
    }

    //display loading icon
    public void LoadingShow(){
        // custom dialog
        dialog3 = new Dialog(this);
        dialog3.setContentView(R.layout.loadingicon);
        dialog3.setTitle("Loading");
        dialog3.setCanceledOnTouchOutside(false);
        dialog3.show();
    }
    //Thread to check details of login that the user entered
    private class CheckUsernamePassword extends AsyncTask<String, Void, Boolean> {
        String usr;
        String pass;

        public CheckUsernamePassword(String usr, String pass) {
            this.usr = usr;
            this.pass = pass;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Boolean doInBackground(String... params) {
            return dbConnection.validatePassword(usr, pass);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                if (User.currentUser != null) {
                    if(User.currentUser.getUsername().equals("Admin")) {
                        Intent myIntent = new Intent(MainActivity.this, QueueManage.class);
                        MainActivity.this.startActivity(myIntent);
                        finish();
                    }
                    else{
                        Intent myIntent = new Intent(MainActivity.this, QueueManageClient.class);
                        MainActivity.this.startActivity(myIntent);
                        finish();
                    }
                } else {
                        Toast.makeText(MainActivity.context, "Details are incorrect", Toast.LENGTH_SHORT)
                            .show();
                }
            }
            else {
                Toast.makeText(MainActivity.context, "Details are incorrect", Toast.LENGTH_SHORT)
                        .show();
            }
            dialog3.dismiss();
        }
    }
}