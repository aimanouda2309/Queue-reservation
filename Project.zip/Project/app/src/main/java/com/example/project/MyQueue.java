package com.example.project;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

import sun.bob.mcalendarview.MCalendarView;
import sun.bob.mcalendarview.vo.DateData;

public class MyQueue extends AppCompatActivity {
    static ArrayList<Queue> myqueues;
    static ArrayList<Queue> otherqueues;
    private int index=0;
    private int index2=0;
    private Button previous,next,cancel,swap,accept;
    private TextView textView,textView4;
    private EditText comment;
    private int flag=0;
    //Here on create we set all of our parameters and we load the queue for current user
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myqueue);
        textView = (TextView) findViewById(R.id.textView3);
        previous = (Button) findViewById(R.id.prev3);
        next = (Button) findViewById(R.id.next3);
        swap=(Button) findViewById(R.id.swap);
        cancel=(Button)findViewById(R.id.Cancel);
        accept=(Button)findViewById(R.id.Accept);
        getSupportActionBar().setTitle("My Queue");
        final ActionBar abar = getSupportActionBar();
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(//Center the textview in the ActionBar !
                ActionBar.LayoutParams.WRAP_CONTENT,
                ActionBar.LayoutParams.MATCH_PARENT,
                Gravity.CENTER);
        abar.setDisplayShowCustomEnabled(true);
        abar.setDisplayShowTitleEnabled(true);
        abar.setDisplayHomeAsUpEnabled(true);
        abar.setHomeButtonEnabled(true);
        previous.setEnabled(false);
        next.setEnabled(false);
        cancel.setEnabled(false);
        swap.setEnabled(false);
        accept.setEnabled(false);
        LoadMyQueue load = new LoadMyQueue();
        load.execute("");
        myqueues=new ArrayList<>();
        index=0;
    }

    public void setTextView(){
        index=0;
        if(myqueues!=null) {
            Collections.sort(myqueues, new Comparator<Queue>() {
                @Override
                public int compare(Queue o1, Queue o2) {
                    if(o1.getDate().getTime()>o2.getDate().getTime())
                        return 1;
                    else if(o1.getDate().getTime()<o2.getDate().getTime())
                        return -1;
                    else if (Integer.parseInt(o1.getHour()) > Integer.parseInt(o2.getHour()))
                        return 1;
                    else if (Integer.parseInt(o1.getHour()) < Integer.parseInt(o2.getHour()))
                        return -1;
                    else if (Integer.parseInt(o1.getMin()) > Integer.parseInt(o2.getMin()))
                        return 1;
                    else if (Integer.parseInt(o1.getMin()) < Integer.parseInt(o2.getMin()))
                        return -1;
                    else
                        return 0;
                }
            });
        }
            if (myqueues != null) {
                if(myqueues.size()>1)
                    next.setEnabled(true);
                else
                    next.setEnabled(false);
                cancel.setEnabled(true);
                previous.setEnabled(false);
                swap.setEnabled(true);
                Log.i("xx",myqueues.size()+"mm"+index);
                textView.setText(myqueues.get(index).getFullName() + "\n" + myqueues.get(index).getDate().toString()+"\n"+myqueues.get(index).getStartTime() + "-" + myqueues.get(index).getEndTime() + "\n" + myqueues.get(index).getDescreption());
                if(myqueues.get(index).getreplacednumber()!=0)
                    accept.setEnabled(true);
            } else {
                textView.setText("");
                next.setEnabled(false);
                previous.setEnabled(false);
                cancel.setEnabled(false);
                swap.setEnabled(false);
                accept.setEnabled(false);

            }
    }
    public void setTextViewWithOther(){
        index=0;
        if(otherqueues!=null) {
            Collections.sort(otherqueues, new Comparator<Queue>() {
                @Override
                public int compare(Queue o1, Queue o2) {
                    if(o1.getDate().getTime()>o2.getDate().getTime())
                        return 1;
                    else if(o1.getDate().getTime()<o2.getDate().getTime())
                        return -1;
                    else if (Integer.parseInt(o1.getHour()) > Integer.parseInt(o2.getHour()))
                        return 1;
                    else if (Integer.parseInt(o1.getHour()) < Integer.parseInt(o2.getHour()))
                        return -1;
                    else if (Integer.parseInt(o1.getMin()) > Integer.parseInt(o2.getMin()))
                        return 1;
                    else if (Integer.parseInt(o1.getMin()) < Integer.parseInt(o2.getMin()))
                        return -1;
                    else
                        return 0;
                }
            });
        }
        if (otherqueues != null) {
            if(otherqueues.size()>1)
                next.setEnabled(true);
            else
                next.setEnabled(false);
            previous.setEnabled(false);
            cancel.setEnabled(true);
            swap.setEnabled(true);
            textView.setText(otherqueues.get(index).getFullName() + "\n" + otherqueues.get(index).getDate().toString()+"\n"+otherqueues.get(index).getStartTime() + "-" + otherqueues.get(index).getEndTime() + "\n" + otherqueues.get(index).getDescreption());
        } else {
            textView.setText("");
            next.setEnabled(false);
            previous.setEnabled(false);
            cancel.setEnabled(false);
            swap.setEnabled(false);
        }
    }
    public void Next(View view) {
        if(swap.getText().equals("swap with other")) {
            index++;
            previous.setEnabled(true);
            textView = (TextView) findViewById(R.id.textView3);
            textView.setText(myqueues.get(index).getFullName() + "\n" + myqueues.get(index).getDate().toString() + "\n" + myqueues.get(index).getStartTime() + "-" + myqueues.get(index).getEndTime() + "\n" + myqueues.get(index).getDescreption());
            if (myqueues.size() == index + 1)
                next.setEnabled(false);
            if(myqueues.get(index).getreplacednumber()!=0)
                accept.setEnabled(true);
            else
                accept.setEnabled(false);
        }else{
            accept.setEnabled(false);
            index++;
            previous.setEnabled(true);
            textView = (TextView) findViewById(R.id.textView3);
            textView.setText(otherqueues.get(index).getFullName() + "\n" + otherqueues.get(index).getDate().toString() + "\n" + otherqueues.get(index).getStartTime() + "-" + otherqueues.get(index).getEndTime() + "\n" + otherqueues.get(index).getDescreption());
            if (otherqueues.size() == index + 1)
                next.setEnabled(false);

        }
    }


    public void Previous(View view) {
        if(swap.getText().equals("swap with other")) {
            index--;
            next.setEnabled(true);
            textView = (TextView) findViewById(R.id.textView3);
            textView.setText(myqueues.get(index).getFullName() + "\n" + myqueues.get(index).getDate().toString() + "\n" + myqueues.get(index).getStartTime() + "-" + myqueues.get(index).getEndTime() + "\n" + myqueues.get(index).getDescreption());
            if (index == 0)
                previous.setEnabled(false);
            if(myqueues.get(index).getreplacednumber()!=0)
                accept.setEnabled(true);
            else
                accept.setEnabled(false);
        }else{
            accept.setEnabled(false);
            index--;
            next.setEnabled(true);
            textView = (TextView) findViewById(R.id.textView3);
            textView.setText(otherqueues.get(index).getFullName() + "\n" + otherqueues.get(index).getDate().toString() + "\n" + otherqueues.get(index).getStartTime() + "-" + otherqueues.get(index).getEndTime() + "\n" + otherqueues.get(index).getDescreption());
            if (index == 0)
                previous.setEnabled(false);
        }
    }
    public void Cancel(View view) {
        if(swap.getText().equals("swap with other")) {
            next.setEnabled(false);
            previous.setEnabled(false);
            cancel.setEnabled(false);
            swap.setEnabled(false);
            accept.setEnabled(false);
            CancelQueue load = new CancelQueue(Integer.parseInt(myqueues.get(index).getYear()), Integer.parseInt(myqueues.get(index).getMonth()), Integer.parseInt(myqueues.get(index).getDay()), myqueues.get(index));
            load.execute("");
        }else{
            accept.setEnabled(false);
            swap.setText("swap with other");
            cancel.setText("cancel");
            ((EditText) findViewById(R.id.Year)).setText("");
            ((EditText) findViewById(R.id.Month)).setText("");
            ((EditText) findViewById(R.id.Day)).setText("");
            LoadMyQueue load = new LoadMyQueue();
            load.execute("");
        }
    }
    public void Swap(View view) {
        if(swap.getText().equals("Sent swap request Email")){
            GetUser to=new GetUser(otherqueues.get(index).getId());
            to.execute("");
        }
        else {
            index2=index;
            swap.setText("Sent swap request Email");
            cancel.setText("Back to my Queue");
            next.setEnabled(false);
            previous.setEnabled(false);
            cancel.setEnabled(false);
            swap.setEnabled(false);
            ((EditText) findViewById(R.id.Year)).setText("");
            ((EditText) findViewById(R.id.Month)).setText("");
            ((EditText) findViewById(R.id.Day)).setText("");
            LoadOtherQueue load = new LoadOtherQueue();
            load.execute("");
        }
    }
    public void AccSwap(View view) {
        accept.setEnabled(false);
        AcceptSwap load = new AcceptSwap(myqueues.get(index).getnumber(),myqueues.get(index).getreplacednumber());
        load.execute("");
    }
    public void search(View view) {
        String year=((EditText) findViewById(R.id.Year)).getText().toString();
        String month=((EditText) findViewById(R.id.Month)).getText().toString();
        String day=((EditText) findViewById(R.id.Day)).getText().toString();
        if(swap.getText().equals("Sent swap request Email")){
            if ((!year.equals("")) || (!month.equals("")) || (!day.equals(""))) {
                LoadOtherQueueat load = new LoadOtherQueueat(year, month, day);
                load.execute("");
            } else {
                LoadOtherQueue load = new LoadOtherQueue();
                load.execute("");
            }
        }else {
            if ((!year.equals("")) || (!month.equals("")) || (!day.equals(""))) {
                LoadMyQueueat load = new LoadMyQueueat(year, month, day);
                load.execute("");
            } else {
                LoadMyQueue load = new LoadMyQueue();
                load.execute("");
            }
        }
    }
    public void SendEmail(User user) {
        String message="Hello my name is "+User.currentUser.getFullName()+
                "\n Do you want to change your queue at \n"+
                otherqueues.get(index).getDate().toString() +" "+otherqueues.get(index).getStartTime()+
                " with my queue at \n"+myqueues.get(index2).getDate().toString()+" "+myqueues.get(index2).getStartTime()+
                " If yes please approve the swap request at the queue on the app";
        Intent email = new Intent(Intent.ACTION_SEND);
        email.putExtra(Intent.EXTRA_EMAIL, new String[]{ user.getEmail()});
        email.putExtra(Intent.EXTRA_SUBJECT, "Change queue");
        email.putExtra(Intent.EXTRA_TEXT, message);
//need this to prompts email client only
        email.setType("message/rfc822");
        startActivity(Intent.createChooser(email, User.currentUser.getEmail()));
        Savereplacednumber load = new Savereplacednumber(myqueues.get(index2).getnumber(),otherqueues.get(index).getnumber());
        load.execute("");
    }
    //Thread to check details of login that the user entered
    private class Savereplacednumber extends AsyncTask<String, Void, Boolean> {

        int number;
        int otherqueuenum;
        public Savereplacednumber(int number,int otherqueuenum) {
            this.number=number;
            this.otherqueuenum=otherqueuenum;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Boolean doInBackground(String... params) {
            return dbConnection.savereplacednum(number,otherqueuenum);
        }

        @Override
        protected void onPostExecute(Boolean result) {

        }
    }
    //Thread to check details of login that the user entered
    private class GetUser extends AsyncTask<String, Void, User> {

        String id;
        public GetUser(String id) {
            this.id=id;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected User doInBackground(String... params) {
            return dbConnection.getuser(id);
        }

        @Override
        protected void onPostExecute(User result) {
            String orders="Order this month: ";
            int i;
            if (result != null) {
                SendEmail(result);
            } else {
                Toast.makeText(MainActivity.context, "No email available for this user", Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }
    //Thread to check details of login that the user entered
    private class LoadMyQueue extends AsyncTask<String, Void, ArrayList<Queue>> {


        public LoadMyQueue() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadmyqueue();
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
            String orders="Order this month: ";
            int i;
            if (result != null) {
                myqueues=new ArrayList<>();
                MyQueue.myqueues=result;
                setTextView();
            } else {
                textView.setText("No Queue assigned for you");
                Log.i("ss", "cv");
            }
        }
    }
    //Thread to check details of login that the user entered
    private class LoadMyQueueat extends AsyncTask<String, Void, ArrayList<Queue>> {
        String year;
        String month;
        String day;

        public LoadMyQueueat(String year,String month,String day) {
            this.year= year;
            this.month= month;
            this.day= day;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadmyqueueat(year,month,day);
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
            String orders="Order this month: ";
            int i;
            if (result != null) {
                myqueues=new ArrayList<>();
                MyQueue.myqueues=result;
                setTextView();
            } else {
                textView.setText("No Queue assigned for you");
                next.setEnabled(false);
                previous.setEnabled(false);
                cancel.setEnabled(false);
                swap.setEnabled(false);
                accept.setEnabled(false);
                Log.i("ss", "cv");
            }
        }
    }
    //Thread to check details of login that the user entered
    private class LoadOtherQueue extends AsyncTask<String, Void, ArrayList<Queue>> {


        public LoadOtherQueue() {
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadotherqueue();
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
            int i;
            if (result != null) {
                    MyQueue.otherqueues = result;
                    setTextViewWithOther();
            } else {
                textView.setText("No Queue for others");
                next.setEnabled(false);
                previous.setEnabled(false);
                cancel.setEnabled(false);
                swap.setEnabled(false);
                accept.setEnabled(false);
                Log.i("ss", "cv");
            }
        }
    }
    //Thread to check details of login that the user entered
    private class LoadOtherQueueat extends AsyncTask<String, Void, ArrayList<Queue>> {
        String year;
        String month;
        String day;

        public LoadOtherQueueat(String year,String month,String day) {
            this.year= year;
            this.month= month;
            this.day= day;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadotherqueueat(year,month,day);
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
            String orders="Order this month: ";
            int i;
            if (result != null) {
                otherqueues=new ArrayList<>();
                MyQueue.otherqueues=result;
                setTextViewWithOther();
            } else {
                textView.setText("No Queue for others");
                next.setEnabled(false);
                previous.setEnabled(false);
                swap.setEnabled(false);
                accept.setEnabled(false);
                Log.i("ss", "cv");
            }
        }
    }
    //Thread to check details of login that the user entered
    private class AcceptSwap extends AsyncTask<String, Void, Boolean> {

        int number;
        int otherqueue;
        public AcceptSwap(int number,int otherqueue) {
            this.number=number;
            this.otherqueue=otherqueue;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Boolean doInBackground(String... params) {
            return dbConnection.acceptswap(number,otherqueue);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                LoadMyQueue load=new LoadMyQueue();
                load.execute("");
                Toast.makeText(MainActivity.context, "The swapped Done", Toast.LENGTH_SHORT)
                        .show();
            } else {
                LoadMyQueue load=new LoadMyQueue();
                load.execute("");
                Toast.makeText(getBaseContext(), "The swapped queue is not exist", Toast.LENGTH_SHORT)
                        .show();
                Log.i("xx","no");
            }
        }
    }
    //Thread to check details of login that the user entered
    private class CancelQueue extends AsyncTask<String, Void, Boolean> {
        int year;
        int month;
        int dayOfMonth;
        Queue cancelqueue;

        public CancelQueue(int year, int month, int dayOfMonth,Queue cancelqueue) {
            this.year = year;
            this.month = month;
            this.dayOfMonth = dayOfMonth;
            this.cancelqueue=cancelqueue;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Boolean doInBackground(String... params) {
            return dbConnection.cancelqueue(year, month, dayOfMonth,cancelqueue);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Toast.makeText(MainActivity.context, "Meeting has been Canceled", Toast.LENGTH_SHORT)
                        .show();
                LoadMyQueue load = new LoadMyQueue();
                load.execute("");
            } else {
                Toast.makeText(MainActivity.context, "Meeting didn't Canceled", Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }
}

