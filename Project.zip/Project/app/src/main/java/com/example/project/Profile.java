package com.example.project;

import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Profile extends AppCompatActivity {

    static Dialog dialog3=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);
        getSupportActionBar().setTitle("My Profile");
        ((EditText)findViewById(R.id.editTextFullName2)).setText(User.currentUser.getFullName());
        ((EditText)findViewById(R.id.editTextAge2)).setText(User.currentUser.getAge());
        ((EditText)findViewById(R.id.MyPhone2)).setText(User.currentUser.getPhone());
        ((EditText)findViewById(R.id.MyEmail2)).setText(User.currentUser.getEmail());
    }
    public void LoadingShow(){
        // custom dialog
        dialog3 = new Dialog(this);
        dialog3.setContentView(R.layout.loadingicon);
        dialog3.setTitle("Loading");
        dialog3.setCanceledOnTouchOutside(false);
        dialog3.show();
    }

    //Save user registration details at DB
    public void save(View view){
        String FullName = ((EditText)findViewById(R.id.editTextFullName2)).getText().toString();
        String Age = ((EditText)findViewById(R.id.editTextAge2)).getText().toString();
        String phone = ((EditText)findViewById(R.id.MyPhone2)).getText().toString();
        String email = ((EditText)findViewById(R.id.MyEmail2)).getText().toString();
        LoadingShow();
        SaveChanges change = new SaveChanges(FullName,Age,phone,email);
        change.execute("");

    }
    //Thread to Save user details at DB
    private class SaveChanges extends AsyncTask<String, Void, Boolean> {
        String FullName;
        String Age;
        String Phone;
        String Email;


        public SaveChanges(String FullName, String Age, String Phone, String Email){
            this.FullName=FullName;
            this.Age=Age;
            this.Phone=Phone;
            this.Email=Email;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        @Override
        protected Boolean doInBackground(String... params) {
            return dbConnection.savechanges(User.currentUser.getUsername(), FullName, Age, User.currentUser.getId(), Phone, Email);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if(result){
                User.currentUser.setAge(Age);
                User.currentUser.setEmail(Email);
                User.currentUser.setFullName(FullName);
                User.currentUser.setPhone(Phone);
                Toast.makeText(MainActivity.context, "Changes saved", Toast.LENGTH_SHORT)
                        .show();
            }else{
                Toast.makeText(MainActivity.context, "Changes not saved", Toast.LENGTH_SHORT)
                        .show();
            }
            dialog3.dismiss();
        }
    }

}
