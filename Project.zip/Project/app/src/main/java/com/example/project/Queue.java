package com.example.project;

import java.sql.Time;
import java.text.SimpleDateFormat;

import java.text.ParseException;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class Queue {
    private int number;
    private String id;
    private String starttime;
    private String endtime;
    private String year;
    private String month;
    private String day;
    private String descreption;
    private String fullName;
    private Date date;
    private String hour;
    private String min;
    private int replacednumber;
    public Queue( int number,String id,String starttime,String year,String month,String day,String descreption,String fullName, String endtime,Date date,int replacednumber) {
        this.number=number;
        this.id = id;
        this.starttime = starttime;
        this.fullName = fullName;
        this.year = year;
        this.month = month;
        this.day = day;
        this.descreption = descreption;
        this.endtime = endtime;
        this.date = date;
        this.replacednumber=replacednumber;
        hour=starttime.split(":")[0];
        min=starttime.split(":")[1];
    }
    public String getId() {
        return id;
    }

    public String getEndTime() {
        return endtime;
    }

    public String getStartTime() { return starttime; }

    public String getFullName() {
        return fullName;
    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public String getDay() {
        return day;
    }

    public String getDescreption() {
        return descreption;
    }
    public Date getDate() {
        return date;
    }
    public String getHour() {
        return hour;
    }
    public String getMin() {
        return min;
    }
    public int getnumber() {
        return number;
    }

    public int getreplacednumber() {
        return replacednumber;
    }



}
