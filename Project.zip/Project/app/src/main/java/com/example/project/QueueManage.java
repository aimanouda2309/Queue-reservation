package com.example.project;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.CalendarView.OnDateChangeListener;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

public class QueueManage extends AppCompatActivity {
    static ArrayList<Queue> TodayQueue;
    private int index=0;
    private Button previous,next;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.queue);
        getSupportActionBar().setTitle("Queues");
        CalendarView calendarView = (CalendarView) findViewById(R.id.calendarView);
        long date = calendarView.getDate();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date);
        int Year = calendar.get(Calendar.YEAR);
        int Month = calendar.get(Calendar.MONTH);
        int Day = calendar.get(Calendar.DAY_OF_MONTH);
        textView = (TextView) findViewById(R.id.textView);
        previous = (Button) findViewById(R.id.prev);
        next = (Button) findViewById(R.id.next);
        previous.setEnabled(false);
        next.setEnabled(false);
        LoadQueue load = new LoadQueue(Year, Month+1, Day);
        load.execute("");
        TodayQueue=new ArrayList<>();
        index=0;
        calendarView.setOnDateChangeListener(new OnDateChangeListener() {
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                LoadQueue load = new LoadQueue(year, month+1, dayOfMonth);
                load.execute("");
                TodayQueue=new ArrayList<>();
                index=0;
                previous.setEnabled(false);
                next.setEnabled(false);
                /*
                for (int i=0; i<MainActivity.queues.size(); i++)
                {
                    if(MainActivity.queues.get(i).getDay().equals(Integer.toString(dayOfMonth))&&
                            MainActivity.queues.get(i).getMonth().equals(Integer.toString(month+1)) &&
                            MainActivity.queues.get(i).getYear().equals(Integer.toString(year))){
                        TodayQueue.add(MainActivity.queues.get(i));
                    }
                }*/
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.LogOutMenu:
                Intent intent = new Intent(QueueManage.this, MainActivity.class);
                startActivity(intent);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void setTextView(){
        index=0;
        if(TodayQueue!=null) {
            Collections.sort(TodayQueue, new Comparator<Queue>() {
                @Override
                public int compare(Queue o1, Queue o2) {
                    if(o1.getDate().getTime()>o2.getDate().getTime())
                        return 1;
                    else if(o1.getDate().getTime()<o2.getDate().getTime())
                        return -1;
                    else if (Integer.parseInt(o1.getHour()) > Integer.parseInt(o2.getHour()))
                        return 1;
                    else if (Integer.parseInt(o1.getHour()) < Integer.parseInt(o2.getHour()))
                        return -1;
                    else if (Integer.parseInt(o1.getMin()) > Integer.parseInt(o2.getMin()))
                        return 1;
                    else if (Integer.parseInt(o1.getMin()) < Integer.parseInt(o2.getMin()))
                        return -1;
                    else
                        return 0;
                }
            });
        }
        if(TodayQueue!=null) {
            if (TodayQueue.size() > 0) {
                if (TodayQueue.size() > 1)
                    next.setEnabled(true);
                else
                    next.setEnabled(false);
                previous.setEnabled(false);
                textView.setText(TodayQueue.get(index).getFullName() + "\n" + TodayQueue.get(index).getDate().toString() + "\n" + TodayQueue.get(index).getStartTime() + "-" + TodayQueue.get(index).getEndTime() + "\n" + TodayQueue.get(index).getDescreption());
            } else {
                textView.setText("No Queue found");
                next.setEnabled(false);
                previous.setEnabled(false);
            }
        }else{
            textView.setText("No Queue found");
            next.setEnabled(false);
            previous.setEnabled(false);
        }
    }
    public void Next(View view) {
            index++;
            previous.setEnabled(true);
            textView = (TextView) findViewById(R.id.textView);
            textView.setText(TodayQueue.get(index).getFullName() + "\n" + TodayQueue.get(index).getDate().toString() + "\n" + TodayQueue.get(index).getStartTime() + "-" + TodayQueue.get(index).getEndTime() + "\n" + TodayQueue.get(index).getDescreption());
        if(TodayQueue.size()==index+1)
            next.setEnabled(false);
    }
    public void search(View view) {
        String fullname=((EditText)findViewById(R.id.CusSearch)).getText().toString();
        if(fullname.equals("")){
            CalendarView calendarView = (CalendarView) findViewById(R.id.calendarView);
            long date = calendarView.getDate();
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(date);
            int Year = calendar.get(Calendar.YEAR);
            int Month = calendar.get(Calendar.MONTH);
            int Day = calendar.get(Calendar.DAY_OF_MONTH);
            LoadQueue load = new LoadQueue(Year, Month+1, Day);
            load.execute("");
        }else {
            LoadQueueFor load = new LoadQueueFor(fullname);
            load.execute("");
        }
    }

    public void Previous(View view) {
            index--;
            next.setEnabled(true);
            textView = (TextView) findViewById(R.id.textView);
            textView.setText(TodayQueue.get(index).getFullName() + "\n" + TodayQueue.get(index).getDate().toString() + "\n" + TodayQueue.get(index).getStartTime() + "-" + TodayQueue.get(index).getEndTime() + "\n" + TodayQueue.get(index).getDescreption());
        if(index==0)
            previous.setEnabled(false);
    }
    //Thread to check details of login that the user entered
    private class LoadQueueFor extends AsyncTask<String, Void, ArrayList<Queue>> {

        String fullname;
        public LoadQueueFor(String fullname) {
            this.fullname=fullname;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadqueuefor(fullname);
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
                QueueManage.TodayQueue=result;
                setTextView();

            //dialog3.dismiss();
        }
    }
    //Thread to check details of login that the user entered
    private class LoadQueue extends AsyncTask<String, Void, ArrayList<Queue>> {
        int year;
        int month;
        int dayOfMonth;

        public LoadQueue(int year, int month, int dayOfMonth) {
            this.year=year;
            this.month=month;
            this.dayOfMonth=dayOfMonth;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected ArrayList<Queue> doInBackground(String... params) {
            return dbConnection.loadqueueat(year, month, dayOfMonth);
        }

        @Override
        protected void onPostExecute(ArrayList<Queue> result) {
                QueueManage.TodayQueue=result;
                setTextView();
            //dialog3.dismiss();
        }
    }
}
