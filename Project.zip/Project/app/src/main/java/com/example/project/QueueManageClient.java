package com.example.project;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CalendarView.OnDateChangeListener;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

public class QueueManageClient extends AppCompatActivity  {

        static ArrayList<Queue> TodayQueue;
        private int index=0;
        private TextView textView;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.selectpage);
            getSupportActionBar().hide();
            textView=(TextView)findViewById(R.id.Name);
            textView.setText("Welcome\n"+User.currentUser.getFullName());
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        return true;
    }


    public void EmptyQueue(View view) {
        Intent myIntent = new Intent(QueueManageClient.this, AssignQueue.class);
        QueueManageClient.this.startActivity(myIntent);
        }
    public void MyQueue(View view) {
        Intent myIntent = new Intent(QueueManageClient.this, MyQueue.class);
        QueueManageClient.this.startActivity(myIntent);
    }
    public void Logout(View view) {
        Intent intent = new Intent(QueueManageClient.this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    public void GotoProfile(View view) {
        Intent myIntent = new Intent(QueueManageClient.this, Profile.class);
        QueueManageClient.this.startActivity(myIntent);
    }
        //Thread to check details of login that the user entered
        private class LoadQueue extends AsyncTask<String, Void, ArrayList<Queue>> {
            int year;
            int month;
            int dayOfMonth;

            public LoadQueue(int year, int month, int dayOfMonth) {
                this.year=year;
                this.month=month;
                this.dayOfMonth=dayOfMonth;
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected ArrayList<Queue> doInBackground(String... params) {
                return dbConnection.loadqueueat(year, month, dayOfMonth);
            }

            @Override
            protected void onPostExecute(ArrayList<Queue> result) {
                if (result!=null) {
                    com.example.project.QueueManage.TodayQueue=result;

                }
                else{
                    textView.setText("");
                    Log.i("ss","cv");
                }
                //dialog3.dismiss();
            }
        }
    }

