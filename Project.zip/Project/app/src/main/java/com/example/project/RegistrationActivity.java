package com.example.project;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
//Registration Activity where the user could create account on the app
public class RegistrationActivity extends AppCompatActivity {

    static Dialog dialog3=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);
        getSupportActionBar().hide();

    }
    public void LoadingShow(){
        // custom dialog
        dialog3 = new Dialog(this);
        dialog3.setContentView(R.layout.loadingicon);
        dialog3.setTitle("Loading");
        dialog3.setCanceledOnTouchOutside(false);
        dialog3.show();
    }
    //Back to login page
    public void gotoLogin(View view){
        Intent myIntent = new Intent(RegistrationActivity.this, MainActivity.class);
        RegistrationActivity.this.startActivity(myIntent);
        finish();
    }
    //Save user registration details at DB
     public void registration(View view){
        String Username = ((EditText)findViewById(R.id.editTextUsername)).getText().toString();
        String FullName = ((EditText)findViewById(R.id.editTextFullName)).getText().toString();
        String Password = ((EditText)findViewById(R.id.editTextPassword)).getText().toString();
        String Age = ((EditText)findViewById(R.id.editTextAge)).getText().toString();
         String ID = ((EditText)findViewById(R.id.Myid)).getText().toString();
         String phone = ((EditText)findViewById(R.id.MyPhone)).getText().toString();
         String email = ((EditText)findViewById(R.id.MyEmail)).getText().toString();
         LoadingShow();
         SignUp signup = new SignUp(Username,FullName,Password,Age,ID,phone,email);
         signup.execute("");

    }
    //Thread to Save user details at DB
    private class SignUp extends AsyncTask<String, Void, Integer> {
        String res = "";
        String Username;
        String FullName;
        String Password;
        String Age;
        String Id;
        String Phone;
        String Email;


        public SignUp(String Username, String FullName, String Password, String Age, String Id, String Phone, String Email){
            this.FullName=FullName;
            this.Username=Username;
            this.Password=Password;
            this.Age=Age;
            this.Id=Id;
            this.Phone=Phone;
            this.Email=Email;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(RegistrationActivity.this, "Please wait...", Toast.LENGTH_SHORT)
                    .show();
        }
        @Override
        protected Integer doInBackground(String... params) {
            return dbConnection.signup(Username, FullName, Password, Age, Id, Phone, Email);
        }

        @Override
        protected void onPostExecute(Integer result) {
            if(result==0){
                Toast.makeText(MainActivity.context, "Account is Already in our system", Toast.LENGTH_SHORT)
                        .show();
            }else if(result==1){
                Toast.makeText(MainActivity.context, "Id is Already in our system", Toast.LENGTH_SHORT)
                        .show();
            }
            else if(result==2){
                Toast.makeText(MainActivity.context, "Account Registred Successfully, You can login now...", Toast.LENGTH_SHORT)
                        .show();
            }
            dialog3.dismiss();
        }
    }

}
