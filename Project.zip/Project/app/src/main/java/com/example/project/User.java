package com.example.project;


import java.lang.reflect.Array;
import java.util.ArrayList;

public class User {
    public static User currentUser;

    private String username;
    private String password;
    private String fullName;
    private String age;
    private String id;
    private String phone;
    private String email;


    public User( String username, String password,String fullName, String age,String id,String phone,String email){
        this.id=id;
        this.username=username;
        this.fullName=fullName;
        this.age=age;
        this.email=email;
        this.phone=phone;
        this.password=password;
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAge() {
        return age;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public void setFullName(String fullName) {
         this.fullName=fullName;
    }

    public void setAge(String age) {
        this.age=age;
    }

    public void setPhone(String phone) {
        this.phone=phone;
    }

    public void setEmail(String email) {
        this.email=email;
    }
}
