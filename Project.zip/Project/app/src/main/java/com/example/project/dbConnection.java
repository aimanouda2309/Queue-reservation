package com.example.project;

import android.content.ContentValues;
import android.util.Log;
//import com.example.myapplication.trainingresultsync.trainingresultmotor.SyncResult;
//import android.util.Log;

//import com.example.myapplication.diagnosed_model.Diagnosed;
//import com.example.myapplication.trainingresultmotor.MotorResult;

import java.sql.Array;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class dbConnection {

    public static final String url = "jdbc:mysql://b5umkb8cgr9dwcwo2kch-mysql.services.clever-cloud.com:3306/b5umkb8cgr9dwcwo2kch";
    public static final String user = "uuy0wunh7omrawmb";
    public static final String pass = "BIV3XN1ksQNDLHrU3JtM";
    private static Connection conn;

    /*
    This Class is Responsible for DB Functions
     */
    public static Connection getConnection() {
        if(conn==null)
            try {
                Class.forName("com.mysql.jdbc.Driver");
//                conn = DriverManager.getConnection(url, user, pass);
                conn = DriverManager.getConnection(url +  "?user="+user+"&password="+pass+"&characterEncoding=utf8&useSSL=false&useUnicode=true");
            } catch ( Exception throwables) {
                throwables.printStackTrace();
            }
        return conn;
    }
    //schema to update profile changes from the client
    public static boolean savechanges(String Username, String FullName, String Age, String Id, String Phone, String Email){
        Statement st = null;
        try {
            st = getConnection().createStatement();
            st.executeUpdate("UPDATE users SET fullname='" + FullName + "', age='" + Age + "', phone='" + Phone + "', email='" + Email + "' WHERE username='" + Username + "'");
            st.executeUpdate("UPDATE queues SET fullname='" + FullName +"' WHERE id='" + User.currentUser.getId() + "'");
            st.close();
            return true;
        } catch (Exception throwables) {
            throwables.printStackTrace();
            return false;
        }
    }
    //schema to save sign up details for the user in DB
    public static int signup(String Username, String FullName, String Password, String Age, String Id, String Phone, String Email){
        Statement st = null;
        try {
            st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from users WHERE username='"+Username+"'");
            ResultSetMetaData rsmd = rs.getMetaData();

            if (rs.next()) {
                st.close();
                return 0;
            }
            ResultSet rs2 = st.executeQuery("select distinct * from users WHERE id='"+Id+"'");
            ResultSetMetaData rsmd2 = rs2.getMetaData();

            if (rs2.next()) {
                st.close();
                return 1;
            }
            st.executeUpdate("INSERT INTO users (username, password, fullname, age,id,phone,email)  VALUES('" + Username + "', '" + Password+  "','" + FullName + "','"+Age+ "','" + Id + "','" +Phone+"','" +Email+"')");
            st.close();
            return 2;
        } catch (Exception throwables) {
            throwables.printStackTrace();
            return 3;
        }
    }
    //schema to assign this specific queue for the current user
    public static boolean assignqueue(int year, int month, int dayOfMonth,String Starthour,String Startminute,String Endhour,String Endminute,String comment){
        Statement st = null;
        String yearofdate,monthofdate,dayofdate;
        try {
            st = getConnection().createStatement();
            String StartTime=Starthour+":"+Startminute;
            String EndTime=Endhour+":"+Endminute;
            yearofdate=Integer.toString(year);
            if(month<10)
                monthofdate="0"+month;
            else
                monthofdate=Integer.toString(month);
            if(dayOfMonth<10)
                dayofdate="0"+dayOfMonth;
            else
                dayofdate=Integer.toString(dayOfMonth);
            String date=yearofdate+"-"+monthofdate+"-"+dayofdate;
            st.executeUpdate("INSERT INTO queues (id, starttime, year, month,day,descreption,fullname,endtime,date)  VALUES('" + User.currentUser.getId() + "', '" + StartTime+  "','" + Integer.toString(year) + "','"+Integer.toString(month)+ "','" + Integer.toString(dayOfMonth) + "','" +comment + "','"+User.currentUser.getFullName()+"','" + EndTime + "','" + date + "')");
            st.close();
            return true;
        } catch (Exception throwables) {
            throwables.printStackTrace();
            return false;
        }
    }
    //schema to check if the login details are correct
    public static boolean validatePassword(String username, String password){
        try {

            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from users WHERE Username='"+username+"' AND Password='"+password+"'");
            ResultSetMetaData rsmd = rs.getMetaData();

            if (rs.next()) {
                    System.out.println("sxxx");
                    User usr = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
                    User.currentUser = usr;
                    return true;
            }
            System.out.println("uuuu");
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    //schema to cancel the queue for current user
    public static Boolean cancelqueue(int year, int month, int dayOfMonth,Queue cancelqueue){
        try {
            Statement st = getConnection().createStatement();
           // st.executeUpdate("DELETE FROM queues WHERE year='"+Integer.toString(year)+"'");
           st.executeUpdate("DELETE FROM queues WHERE id='"+User.currentUser.getId()+"' AND year='"+Integer.toString(year)+"' AND month='"+Integer.toString(month)+"' AND day='"+Integer.toString(dayOfMonth)+"' AND starttime='"+cancelqueue.getStartTime()+"'");
            st.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    //schema to to load current user queues at specific date from DB
    public static ArrayList<Queue> loadmyqueueat(String year, String month, String dayOfMonth){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs;
            if(month.equals("") &&dayOfMonth.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(year.equals("") &&dayOfMonth.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE month='"+month+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(year.equals("") &&month.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE day='"+dayOfMonth+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(dayOfMonth.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"' AND month='"+month+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(month.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"' AND day='"+dayOfMonth+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(year.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE month='"+month+"' AND day='"+dayOfMonth+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else{
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"' AND month='"+month+"' AND day='"+dayOfMonth+"'AND id='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }

            if(queues.size()>0)
                return queues;
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to to load other users queues at specific date from DB
    public static ArrayList<Queue> loadotherqueueat(String year, String month, String dayOfMonth){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs;
            if(month.equals("") &&dayOfMonth.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(year.equals("") &&dayOfMonth.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE month='"+month+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(year.equals("") &&month.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE day='"+dayOfMonth+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(dayOfMonth.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"' AND month='"+month+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(month.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"' AND day='"+dayOfMonth+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else if(year.equals("")){
                rs = st.executeQuery("select distinct * from queues WHERE month='"+month+"' AND day='"+dayOfMonth+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            else{
                rs = st.executeQuery("select distinct * from queues WHERE year='"+year+"' AND month='"+month+"' AND day='"+dayOfMonth+"'AND id!='"+User.currentUser.getId()+"'");
                ResultSetMetaData rsmd = rs.getMetaData();
            }
            while (rs.next()) {
                Queue otherqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(otherqueue);
            }

            if(queues.size()>0)
                return queues;
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to to load other users queues at specific date from DB
    /*
    public static ArrayList<Queue> loadmyqueueat(int year, int month, int dayOfMonth){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from queues WHERE year='"+Integer.toString(year)+"' AND month='"+Integer.toString(month)+"'AND day='"+Integer.toString(dayOfMonth)+"'AND id='"+User.currentUser.getId()+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }

            if(queues.size()>0)
                return queues;
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }*/
    //schema to to load all users queues from DB
    public static ArrayList<Queue> loadqueue(){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from queues");
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }

           if(queues.size()>0)
                return queues;
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to load queues for user with fullname from DB
    public static ArrayList<Queue> loadqueuefor(String fullname){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from queues WHERE fullname='"+fullname+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }

            if(queues.size()>0)
                return queues;
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to get object user with the specific id
    public static User getuser(String id){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from users WHERE id='"+id+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
            if (rs.next()) {
                User user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                return user;
            }
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to load others queues from DB
    public static ArrayList<Queue> loadotherqueue(){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from queues WHERE id!='"+User.currentUser.getId()+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }
            st.close();
            if(queues.size()>0)
                return queues;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to load queues for current user from DB
    public static ArrayList<Queue> loadmyqueue(){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from queues WHERE id='"+User.currentUser.getId()+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }
            st.close();
            if(queues.size()>0)
                return queues;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to load queues at specific date from DB
    public static ArrayList<Queue> loadqueueat(int year, int month, int dayOfMonth){
        ArrayList<Queue> queues=new ArrayList<>();
        try {
            Statement st = getConnection().createStatement();
            ResultSet rs = st.executeQuery("select distinct * from queues WHERE year='"+Integer.toString(year)+"' AND month='"+Integer.toString(month)+"'AND day='"+Integer.toString(dayOfMonth)+"'");
            ResultSetMetaData rsmd = rs.getMetaData();
            while (rs.next()) {
                Queue myqueue = new Queue(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDate(10),rs.getInt(11));
                queues.add(myqueue);
            }
            st.close();
            if(queues.size()>0)
                return queues;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    //schema to save the queue for swap on the DB
    public static boolean savereplacednum(int number,int otherqueuenum){
        Statement st = null;
        try {
            st = getConnection().createStatement();
            st.executeUpdate("UPDATE queues SET replacednum ='"+ number+ "' WHERE number='"+otherqueuenum+"'");
            st.close();
            return true;
        } catch (Exception throwables) {
            throwables.printStackTrace();
            return false;
        }
    }
    //schema to change the queue owner after he accept the swap with other user
    public static boolean acceptswap(int number,int otherqueuenum){
        Statement st1 = null;
        Statement st2 = null;
        try {
            st1 = getConnection().createStatement();
            st2 = getConnection().createStatement();
            ResultSet rs1 = st1.executeQuery("select distinct * from queues WHERE number='"+otherqueuenum+"'");
            ResultSet rs2 = st2.executeQuery("select distinct * from queues WHERE number='"+number+"'");
            ResultSetMetaData rsmd1 = rs1.getMetaData();
            ResultSetMetaData rsmd2 = rs2.getMetaData();
            if(rs1.next()){
                Log.i("bbb",number+","+otherqueuenum);
                if(rs2.next()) {
                    st2.executeUpdate("UPDATE queues SET id ='" + rs2.getString(2) + "', descreption='" + rs2.getString(7) + "', fullname='" + rs2.getString(8) + "', replacednum=0 WHERE number='" + otherqueuenum + "'");
                    st1.executeUpdate("UPDATE queues SET id ='" + rs1.getString(2) + "', descreption='" + rs1.getString(7) + "', fullname='" + rs1.getString(8) + "', replacednum=0 WHERE number='" + number + "'");
                    st1.close();
                    st2.close();
                    return true;
                }
            }
          else{
                st1.executeUpdate("UPDATE queues SET replacednum=0 WHERE number='" + number + "'");
                st1.close();
                st2.close();
                return false;
            }
        } catch (Exception throwables) {
            throwables.printStackTrace();
            return false;
        }
        return false;
    }
}
